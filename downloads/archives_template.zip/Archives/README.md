# Standalone PDF Archive System

Welcome to your offline, client-side PDF Archive search console.

## Quick Start Setup

1. **Place your PDFs**: Move your PDF documents into the `pdfs` folder.
2. **Install requirements**: Open your terminal/command prompt and install the dependencies:
   ```bash
   pip install PyMuPDF
   ```
3. **Generate your Search Index**: Run the Python script in your terminal to index your documents:
   ```bash
   python build_index.py
   ```
4. **Run your local server**: To bypass browser security restrictions on local file loading, launch a mini local server from the terminal:
   ```bash
   python -m http.server 8000
   ```
5. **Open your console**: Open your browser and navigate to:
   http://localhost:8000/archivesindex.html