# Standalone PDF Archive System

Welcome to your offline, client-side PDF Archive search console.

## Quick Start Setup

### 1. Place your PDFs
Move your PDF documents into the `pdfs` folder.

### 2. Generate your Search Index
Open your Terminal (macOS) or Command Prompt (Windows) and navigate to your `pdfs` folder. 
*(Hint: Type `cd ` in Terminal and drag-and-drop the `pdfs` folder from your Finder directly into the Terminal window to auto-fill the path, then press Enter)*.

Run the index generator:
```bash
pip install PyMuPDF
python3 build_index.py
```

### 3. Run your local server
Go back to the parent folder:
```bash
cd ..
```

Start the local server inside the parent folder:
```bash
python3 -m http.server 8000
```

### 4. Open your console
Open your browser and navigate directly to:
[http://localhost:8000/archivesindex.html]